# Dictionary to store tasks
tasks = {}

def add_task():
    task_id = input("Enter Task ID: ")
    task_name = input("Enter Task Name: ")
    tasks[task_id] = {'name': task_name, 'status': 'Pending'}
    print("Task added successfully! - to-do-list manegar mini project 141.py:8")

def mark_done():
    task_id = input("Enter Task ID to mark as done: ")
    if task_id in tasks:
        tasks[task_id]['status'] = 'Done'
        print("Task marked as Done ✅ - to-do-list manegar mini project 141.py:14")
    else:
        print("Task not found. - to-do-list manegar mini project 141.py:16")

def delete_task():
    task_id = input("Enter Task ID to delete: ")
    if task_id in tasks:
        del tasks[task_id]
        print("Task deleted successfully. - to-do-list manegar mini project 141.py:22")
    else:
        print("Task not found. - to-do-list manegar mini project 141.py:24")

def view_tasks():
    if not tasks:
        print("No tasks available. - to-do-list manegar mini project 141.py:28")
    else:
        for task_id, info in tasks.items():
            print(f"[{task_id}] {info['name']} - {info['status']} - to-do-list manegar mini project 141.py:31")

def save_tasks():
    with open("tasks.txt", "w") as f:
        for task_id, info in tasks.items():
            f.write(f"{task_id},{info['name']},{info['status']}\n")
    print("Tasks saved to tasks.txt - to-do-list manegar mini project 141.py:37")

def load_tasks():
    try:
        with open("tasks.txt", "r") as f:
            for line in f:
                task_id, name, status = line.strip().split(",")
                tasks[task_id] = {'name': name, 'status': status}
        print("Tasks loaded from file. - to-do-list manegar mini project 141.py:45")
    except FileNotFoundError:
        print("No saved tasks found. - to-do-list manegar mini project 141.py:47")

# Main menu
def main():
    load_tasks()
    while True:
        print("\n====== TO-DO LIST MANAGER ====== - to-do-list manegar mini project 141.py:53")
        print("1. Add Task - to-do-list manegar mini project 141.py:54")
        print("2. View Tasks - to-do-list manegar mini project 141.py:55")
        print("3. Mark Task as Done - to-do-list manegar mini project 141.py:56")
        print("4. Delete Task - to-do-list manegar mini project 141.py:57")
        print("5. Save & Exit - to-do-list manegar mini project 141.py:58")
        choice = input("Enter choice (1-5): ")

        if choice == '1':
            add_task()
        elif choice == '2':
            view_tasks()
        elif choice == '3':
            mark_done()
        elif choice == '4':
            delete_task()
        elif choice == '5':
            save_tasks()
            print("Goodbye! - to-do-list manegar mini project 141.py:71")
            break
        else:
            print("Invalid choice. Try again. - to-do-list manegar mini project 141.py:74")

main()
