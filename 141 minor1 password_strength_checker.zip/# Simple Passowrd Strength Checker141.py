# Simple Passowrd Strength Checker L

def password_strength(password):
    # Tuples for character types
    uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    lowercase = "abcdefghijklmnopqrstuvwxyz"
    digits = "0123456789"
    specials = "!@#$%^&*"

    has_upper = has_lower = has_digit = has_special = False

    for char in password:
        if char in uppercase:
            has_upper = True
        elif char in lowercase:
            has_lower = True
        elif char in digits:
            has_digit = True
        elif char in specials:
            has_special = True

    # Create a tuple of the flags
    checks = (has_upper, has_lower, has_digit, has_special)

    score = sum(checks)

    # Simple strength rules
    if len(password) < 6:
        strength = "Very Weak"
    elif score == 1:
        strength = "Weak"
    elif score == 2:
        strength = "Medium"
    elif score == 3:
        strength = "Strong"
    elif score == 4:
        strength = "Very Strong"
    else:
        strength = "Unknown"

    print("Password Strength:", strength)


# Run the checker
pwd = input("Enter password: ")
password_strength(pwd)